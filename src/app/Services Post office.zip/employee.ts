export interface EmployeeInf{
    empId:number;
    empName:string;
    empSalary:number;
    empAge:number;
}