import { NgModule, Component } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { EmployeeListComponent } from './employee-list/employee-list.component';
import { AppComponent } from './app.component';
import { TdFormsComponent } from './td-forms/td-forms.component';




const routes: Routes = [
  {
    path:'employee',
    component :EmployeeListComponent

  },
  {  path:'tdForms',
    component: TdFormsComponent
  }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
//export const routingComponents=[EmployeeListComponent]

